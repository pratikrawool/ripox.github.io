<div class="ebs-prodemo-outer">
    <div class="ebspro-titlebar">
        <h1>Easy Bootstrap Shortcode Pro Demo </h1>
        <div class="osc-logo">
            <img src="<?php echo EBS_PLUGIN_URL.'images/osc-logo.png';?>"  alt="" />
        </div>
    </div>

    <div class="ebs-pro-content">
        <div class="ebs-content">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi consequuntur cumque, dolor dolorum eaque, impedit necessitatibus omnis quidem quis reprehenderit vel voluptas! Ea libero molestiae obcaecati perspiciatis tempore totam ullam!.</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi consequuntur cumque, dolor dolorum eaque, impedit necessitatibus omnis quidem quis reprehenderit vel voluptas! Ea libero molestiae obcaecati perspiciatis tempore totam ullam!.</p>
        </div>

       <div class="ebs-pro-update"><img src="<?php echo EBS_PLUGIN_URL.'images/ebspro-highlights.jpg';?>"  alt="" /></div>
    </div>



</div>