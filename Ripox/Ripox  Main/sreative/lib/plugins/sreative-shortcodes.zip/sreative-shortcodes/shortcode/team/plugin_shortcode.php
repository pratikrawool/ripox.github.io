<?php

/* * *********************************************************
 * Team mirage
 * ********************************************************* */

function osc_theme_team($params, $name = 'Label',$position = 'Label',$twitter = 'Label',$facebook = 'Label',$skype = 'Label',$content = 'Label') {
    extract(shortcode_atts(array(
        'src' => '',
		'name' => '',
        'position' => '',
        'twitter' => '',
        'facebook' => '',
        'skype' => '',        
        'content' => ''
    ), $params));
    $out = '';
    $out = '<div class="team_wrapper" data-uk-scrollspy="{cls:\'uk-animation-slide-bottom\', repeat: true}">
                       <img src="' . $src . '" alt="" class="scale-with-grid"/> 
				        <div class="team_wrapper_inner"> 
						  <div class="team_name"> 
				            <h3> ' . $name . ' </h3>
							<div class="t_position">' . $position . '</div>
						  </div>
						  <div class="social_wrapper2">  
							<a href="'.$twitter.'"><i class="fa fa-twitter"></i></a>
                            <a href="'.$facebook.'"><i class="fa fa-facebook"></i></a>
							<a href="'.$skype.'"><i class="fa fa-skype"></i></a>					
		                  </div>
						  <p> ' . $content . ' </p>					                        						  
					    </div> <!-- End Leader wrapper inner -->
                      <div class="clear"></div>						
			   	   </div> <!-- End Leader wrapper -->
						';

    return $out;
}

ebs_backward_compatibility_callback('team', 'osc_theme_team');