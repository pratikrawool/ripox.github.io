<?php

/* * *********************************************************
 * service mirage
 * ********************************************************* */

function osc_theme_service($params, $title = 'Label',$link = 'Label',$content = 'Label',$delay = 'Label') {
    extract(shortcode_atts(array(
        'src' => '',
		'title' => '',
        'link' => '',        
        'content' => '',
		'delay' => ''
    ), $params));
    $out = '';
    $out = '<div class="service_wrapper" data-uk-scrollspy="{cls:\'uk-animation-fade\', delay:' . $delay . ', repeat: true}">						 							     
								<img src="' . $src . '" alt=""/>
								<div class="clear"></div>	
				                <div class="service_wrapper_inner"> 	   
									   <h4><a href="' . $link . '"> ' . $title . ' </a><span style="color:#e43635;">.</span> </h4>
									   <p> 
									    ' . $content . '
									   </p>
									   <a href="' . $link . '"><div class="s_read_more"></div></a>
					            </div> <!-- End service wrapper inner --> 
                            <div class="divider_service"></div>									
					    </div>
						';

    return $out;
}

ebs_backward_compatibility_callback('service', 'osc_theme_service');