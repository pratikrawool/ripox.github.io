<?php

function osc_theme_wp_column($atts, $content = null) {
    extract(shortcode_atts(array(
                'type' => '',
                'class' => ''
                    ), $atts));

    $result = '<div class = "'.$type .'' . $class .EBS_CONTAINER_CLASS. '">';
    $result .= do_shortcode($content);
    $result .= '</div>';

    return $result;
}

ebs_backward_compatibility_callback('wp_column', 'osc_theme_wp_column');