var service={
    title:"Service Default",
    id :'oscitas-form-service',
    pluginName: 'service'
};
(function() {
    _create_tinyMCE_options(service);
})();

function ebs_return_html_service(pluginObj){
    var form = jQuery('<div id="'+pluginObj.id+'" class="oscitas-container" title="'+pluginObj.title+'"><table id="oscitas-table" class="form-table">\
			<th><label for="oscitas-label-content">Upload Image:</label></th>\
				<td id="osc_thumbnail_upload"><input id="oscitas-service-src" type="hidden" name="oscitas-service-src"  value="" />\
                                <input id="_btn" class="upload_image_button" type="button" value="Upload Image" />\
				</td>\
            <tr>\
				<th><label for="oscitas-service-title">Title:</label></th>\
				<td><input style="width: 300px;" type="text" name="line" id="oscitas-service-title" value="Strategy"/><br />\
				</td>\
			</tr>\
			<tr>\
				<th><label for="oscitas-service-content">service Content:</label></th>\
				<td><textarea style="width: 300px; height: 150px;" name="service" id="oscitas-service-content">Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker</textarea><br />\
				</td>\
			</tr>\
			<tr>\
				<th><label for="oscitas-service-link">link:</label></th>\
				<td><input style="width: 300px;" type="text" name="line" id="oscitas-service-link" value="http://google.com"/><br />\
				</td>\
			</tr>\
			<tr>\
				<th><label for="oscitas-service-delay">delay:</label></th>\
				<td><input type="text" name="line" id="oscitas-service-delay" value="0"/><br />\
				</td>\
			</tr>\
		</table>\
		<p class="submit">\
			<input type="button" id="oscitas-service-submit" class="button-primary" value="Insert service" name="submit" />\
		</p>\
		</div>');

    return form;
}
function create_oscitas_service(pluginObj){
   var form=jQuery(pluginObj.hashId);
		
    var table = form.find('table');
    
	form.find('.upload_image_button').click(function() {
        jQuery('body').addClass('ebs_plugin_shown_now');
        jQuery('.ui-widget-overlay, .ui-dialog').css('z-index',100);
        jQuery('html').addClass('Image');
        formfield = jQuery(this).prev().attr('id');
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
        return false;
    });

    window.original_send_to_editor = window.send_to_editor;

    window.send_to_editor = function(html) {
        if (formfield) {
            if (jQuery(html).find('img').length) {
                fileurl = jQuery('img', html).attr('src');
            } else if (jQuery(html).attr('src')) {
                fileurl = jQuery(html).attr('src');
            }
            jQuery('#' + formfield).val(fileurl);
            tb_remove();
            form.find('#osc_thumbnail_upload img').remove();
            form.find('#osc_thumbnail_upload').append('<img src="'+fileurl+'">');
            jQuery('body').removeClass('ebs_plugin_shown_now');
            jQuery('html').removeClass('Image');

        } else {
            window.original_send_to_editor(html);
            jQuery('body').removeClass('ebs_plugin_shown_now');
        }

    };
	
    // handles the click event of the submit button
    form.find('#oscitas-service-submit').click(function(){
        var cusclass='';
        
		var shortcode = '['+$ebs_prefix+'service'+cusclass;
        shortcode += ' src="' + table.find('#oscitas-service-src').val();

        shortcode += '" ';
		
		shortcode += ' title="' + table.find('#oscitas-service-title').val();

        shortcode += '" ';
        
        shortcode += ' content="' + table.find('#oscitas-service-content').val();

        shortcode += '" ';
		
		shortcode += ' link="' + table.find('#oscitas-service-link').val();

        shortcode += '" ';
		
        shortcode += ' delay="' + table.find('#oscitas-service-delay').val();

        shortcode += '" ';

        shortcode += ']';
		
        // inserts the shortcode into the active editor
        tinyMCE.activeEditor.execCommand('mceInsertContent', 0, shortcode);
			
        // closes Dialoguebox
        close_dialogue(pluginObj.hashId);
    });
}

