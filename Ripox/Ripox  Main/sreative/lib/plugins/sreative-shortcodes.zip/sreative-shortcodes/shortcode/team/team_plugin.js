var team={
    title:"Team Default",
    id :'oscitas-form-team',
    pluginName: 'team'
};
(function() {
    _create_tinyMCE_options(team);
})();

function ebs_return_html_team(pluginObj){
    var form = jQuery('<div id="'+pluginObj.id+'" class="oscitas-container" title="'+pluginObj.title+'"><table id="oscitas-table" class="form-table">\
			<th><label for="oscitas-label-content">Upload Image:</label></th>\
				<td id="osc_thumbnail_upload"><input id="oscitas-team-src" type="hidden" name="oscitas-team-src"  value="" />\
                                <input id="_btn" class="upload_image_button" type="button" value="Upload Image" />\
				</td>\
            <tr>\
				<th><label for="oscitas-team-name">Name:</label></th>\
				<td><input style="width: 300px;" type="text" name="line" id="oscitas-team-name" value="Mark Moskal"/><br />\
				</td>\
			</tr>\
			<tr>\
				<th><label for="oscitas-team-position">Position:</label></th>\
				<td><input style="width: 300px;" type="text" name="line" id="oscitas-team-position" value="Co-Founder & Chief Experience Officer"/><br />\
				</td>\
			</tr>\
			<tr>\
				<th><label for="oscitas-team-twitter">Twitter link:</label></th>\
				<td><input style="width: 300px;" type="text" name="line" id="oscitas-team-twitter" value="http://twitter.com"/><br />\
				</td>\
			</tr>\
			<tr>\
				<th><label for="oscitas-team-facebook">facebook link:</label></th>\
				<td><input style="width: 300px;" type="text" name="line" id="oscitas-team-facebook" value="http://facebook.com"/><br />\
				</td>\
			</tr>\
			<tr>\
				<th><label for="oscitas-team-skype">Skype link:</label></th>\
				<td><input style="width: 300px;" type="text" name="line" id="oscitas-team-skype" value="http://skype.com"/><br />\
				</td>\
			</tr>\
			<tr>\
				<th><label for="oscitas-team-content">Team Content:</label></th>\
				<td><textarea style="width: 300px; height: 150px;" name="team" id="oscitas-team-content">Mike is a UK based designer specialising in Web/UI Design, Graphic Design, Branding, Illustration & Photography.</textarea><br />\
				</td>\
			</tr>\
		</table>\
		<p class="submit">\
			<input type="button" id="oscitas-team-submit" class="button-primary" value="Insert team" name="submit" />\
		</p>\
		</div>');

    return form;
}
function create_oscitas_team(pluginObj){
   var form=jQuery(pluginObj.hashId);
		
    var table = form.find('table');
    
	form.find('.upload_image_button').click(function() {
        jQuery('body').addClass('ebs_plugin_shown_now');
        jQuery('.ui-widget-overlay, .ui-dialog').css('z-index',100);
        jQuery('html').addClass('Image');
        formfield = jQuery(this).prev().attr('id');
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
        return false;
    });

    window.original_send_to_editor = window.send_to_editor;

    window.send_to_editor = function(html) {
        if (formfield) {
            if (jQuery(html).find('img').length) {
                fileurl = jQuery('img', html).attr('src');
            } else if (jQuery(html).attr('src')) {
                fileurl = jQuery(html).attr('src');
            }
            jQuery('#' + formfield).val(fileurl);
            tb_remove();
            form.find('#osc_thumbnail_upload img').remove();
            form.find('#osc_thumbnail_upload').append('<img src="'+fileurl+'">');
            jQuery('body').removeClass('ebs_plugin_shown_now');
            jQuery('html').removeClass('Image');

        } else {
            window.original_send_to_editor(html);
            jQuery('body').removeClass('ebs_plugin_shown_now');
        }

    };
	
    // handles the click event of the submit button
    form.find('#oscitas-team-submit').click(function(){
        var cusclass='';
        
		var shortcode = '['+$ebs_prefix+'team'+cusclass;
        shortcode += ' src="' + table.find('#oscitas-team-src').val();

        shortcode += '" ';
		
		shortcode += ' name="' + table.find('#oscitas-team-name').val();

        shortcode += '" ';
		
		shortcode += ' position="' + table.find('#oscitas-team-position').val();

        shortcode += '" ';
		
		shortcode += ' twitter="' + table.find('#oscitas-team-twitter').val();

        shortcode += '" ';
		
		shortcode += ' facebook="' + table.find('#oscitas-team-facebook').val();

        shortcode += '" ';
		
		shortcode += ' skype="' + table.find('#oscitas-team-skype').val();

        shortcode += '" ';
        
        shortcode += ' content="' + table.find('#oscitas-team-content').val();

        shortcode += '" ';

        shortcode += ']';
		
        // inserts the shortcode into the active editor
        tinyMCE.activeEditor.execCommand('mceInsertContent', 0, shortcode);
			
        // closes Dialoguebox
        close_dialogue(pluginObj.hashId);
    });
}

